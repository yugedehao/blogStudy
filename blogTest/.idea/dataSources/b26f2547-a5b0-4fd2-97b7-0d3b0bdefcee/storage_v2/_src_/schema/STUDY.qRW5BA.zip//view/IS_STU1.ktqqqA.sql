create view IS_STU1 as
  select `STUDY`.`STU1`.`Sno` AS `Sno`, `STUDY`.`STU1`.`Sname` AS `Sname`, `STUDY`.`STU1`.`Sage` AS `Sage`
  from `STUDY`.`STU1`
  where (`STUDY`.`STU1`.`Sdept` = 'IS');

