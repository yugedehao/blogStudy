create view IS_Stu as
  select `STUDY`.`Stu`.`Sno` AS `Sno`, `STUDY`.`Stu`.`Sname` AS `Sname`, `STUDY`.`Stu`.`Sage` AS `Sage`
  from `STUDY`.`Stu`
  where (`STUDY`.`Stu`.`Sdept` = 'IS');

